package scripts.ankou_logic;

import scripts.api.Task;

public class KillAnkouHandler implements Task {

	@Override
	public String action() {
		// TODO Auto-generated method stub
		return "Killing Ankous...";
	}

	@Override
	public int priority() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean validate() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}

}
