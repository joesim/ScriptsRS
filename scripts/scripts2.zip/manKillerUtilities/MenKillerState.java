package scripts.manKillerUtilities;

public enum MenKillerState {
	KILLING, CLIMBDOWN, BANKING, OPENDOOR
}
