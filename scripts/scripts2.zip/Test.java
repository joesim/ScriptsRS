package scripts;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import org.tribot.api.DynamicClicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Mouse;
import org.tribot.api.types.generic.Condition;
import org.tribot.api.util.abc.ABCProperties;
import org.tribot.api.util.abc.ABCUtil;
import org.tribot.api2007.Banking;
import org.tribot.api2007.Camera;
import org.tribot.api2007.ChooseOption;
import org.tribot.api2007.Combat;
import org.tribot.api2007.Game;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.Login;
import org.tribot.api2007.NPCs;
import org.tribot.api2007.Objects;
import org.tribot.api2007.Player;
import org.tribot.api2007.Projection;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSObject;
import org.tribot.script.Script;
import org.tribot.script.ScriptManifest;
import org.tribot.script.interfaces.MessageListening07;
import org.tribot.script.interfaces.Painting;

import scripts.chinner_utilities.Conditions;
import scripts.chinner_utilities.Constants;
import scripts.others.DynamicWaiting;
import scripts.others.Screen;
import scripts.utilities.ABC2;
import scripts.utilities.AntiBan;
import scripts.utilities.Functions;
import scripts.utilities.HoverBox;
import scripts.utilities.MouseMoveJoe;
import scripts.utilities.ShiftDrop;
import scripts.utilities.SleepJoe;
import scripts.utilities.TBox;
import scripts.webwalker_logic.shared.helpers.BankHelper;
import scripts.webwalker_logic.teleport_logic.TeleportManager;
import scripts.webwalker_logic.teleport_logic.TeleportManager.TeleportAction;

@ScriptManifest(authors = { "Joe" }, category = "Test", name = "Test")
public class Test extends Script implements Painting, MessageListening07 {

	private ABCUtil abc_util = new ABCUtil();

	private void onStart() {
		//MouseMoveJoe.loadDataNormal();
		for (Thread thread : Thread.getAllStackTraces().keySet()) {
			if (thread.getName().contains("Antiban") || thread.getName().contains("Fatigue")) {
				thread.suspend();
			}
		}
		Mouse.setSpeed(105);
		HoverBox.load();
	}

	@Override
	public void run() {
		onStart();
		// TODO Auto-generated method stub
		// RSObject spinner = Functions.findNearestId(15, 14889);
		// MouseMoveJoe.playMouseFollowObject(spinner, "Spin", 1, null, true, 0,
		// sleep(3000);
		//

		// 0, 0, 0);
		while (true){
			
			sleep(100);
			ABC2.generateTrackers(3000);
			General.sleep(2500, 3500);
			ABC2.sleepReactionTime();
			
			
		}
		
//		General.println("Start");
//		println(DynamicWaiting.hoverWaitScreen(Conditions.bankScreenOpen(), General.random(2000000, 4000000), Screen.ALL_SCREEN));
//		Mouse.move(new Point(700,500));
//		General.println("Hey");
	}
	
	
	public static void waitHover(Condition c, long timeOut, Rectangle rec){
		Integer mSpeed = Mouse.getSpeed();
		Mouse.setSpeed(20);
		long t = Timing.currentTimeMillis();
		while (!c.active() && (Timing.currentTimeMillis()-t)<timeOut){
			
		}
		Mouse.setSpeed(mSpeed);
	}
	

	Font font = new Font("Verdana", Font.BOLD, 14);
	private final long startTime = System.currentTimeMillis();

	@Override
	public void onPaint(Graphics g) {

		long timeRan = (System.currentTimeMillis() - startTime) / 1000;
		g.setFont(font);
		g.setColor(new Color(0, 255, 0));

		g.drawPolygon(Constants.chinningArea.polygon);
		g.drawString("Temps: " + String.format("%d:%02d:%02d", timeRan / 3600, (timeRan % 3600) / 60, (timeRan % 60)),
				20, 70);
		g.drawString("Kills: " + Player.getRSPlayer().getInteractingIndex(), 20, 90);

		// if (Zulrah.zulrah != null) {
		// g.drawString("Zulrah animation: " + Zulrah.zulrah.getAnimation(),
		// 300, 370);
		// }
		// g.drawString("CheckDeath player : " + CheckDeath.playerDead + " zul:
		// " + CheckDeath.zulrahDead, 200, 390);
		// g.drawString("Player interacting index: " +
		// Player.getRSPlayer().getInteractingIndex(), 200, 410);
		// g.drawString("CheckRed shouldMove " + CheckRed.shouldMove, 200, 430);
		// g.drawString("CheckJad " + CheckJad.shouldSwitch, 200, 450);

	}

	@Override
	public void clanMessageReceived(String arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void duelRequestReceived(String arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void personalMessageReceived(String arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void playerMessageReceived(String arg0, String arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void serverMessageReceived(String arg0) {
		General.println(arg0);

	}

	@Override
	public void tradeRequestReceived(String arg0) {
		// TODO Auto-generated method stub

	}
}
