package scripts.woodcuttingUtilities;

import scripts.utilities.Condition;

public class ConditionWc implements Condition {

	@Override
	public boolean checkCondition() {
		
		
		
		return false;
	}

}
