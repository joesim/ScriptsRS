package scripts.woodcuttingUtilities;

public enum WoodcuttingState {
	CUTTING, BANKING, DROPPING
}
