package scripts.ankou_utilities;

public class Variables {

}
