package scripts.utilities;

import org.tribot.api2007.Player;
import org.tribot.script.Script;

public class TestThread extends Script{

	
	@Override
	public void run() {
		
		
//		while (true){
//			for (Thread thread : Thread.getAllStackTraces().keySet()) {
//				if (thread.getName().contains("Antiban") || thread.getName().contains("Fatigue")) {
//					println(thread.getState());
//				}
//			}
//			sleep(100);
//		}
		
	}

	
	
}
