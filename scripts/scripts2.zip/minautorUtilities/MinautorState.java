package scripts.minautorUtilities;

public enum MinautorState {
	
}
