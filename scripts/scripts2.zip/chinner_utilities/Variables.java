package scripts.chinner_utilities;

public class Variables {

	//Potions
	public static int NUMBER_PRAY_POT =0;
	public static int NUMBER_POISON_POT = 0;
	public static int NUMBER_RANGING_POT = 0;
	public static int[] SELECTED_POISON_POT;
	
	//Combat
	public static int AMOUNT_CHINS = 0;
	public static int SELECTED_CHINS = 0;
	public static int SELECTED_COMBAT_STYLE = 0;
	public static int DRINK_RANGE_POT_AT = 0;
	
	//Food
	public static int SELECTED_FOOD = 0;
	public static int NUMBER_FOOD = 0;
	
	//Mouse speed
	public static int MOUSE_SPEED = 100;
}
