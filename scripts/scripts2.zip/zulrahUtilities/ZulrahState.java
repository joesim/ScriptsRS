package scripts.zulrahUtilities;

public enum ZulrahState {
	KILLING, LOOTING, BANKING, RANDOMBREAK, DEAD, WAYBACK, COLLECTITEMS
}
