package scripts.potato_picker.UI;

public class GUIPotato {

}
