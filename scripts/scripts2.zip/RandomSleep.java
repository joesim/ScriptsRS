package scripts;

import org.tribot.api.General;
import org.tribot.script.Script;

public class RandomSleep extends Script{

	@Override
	public void run() {
		while (true){
			if (FlaxSpinning.P_RANDOMSLEEP)
		}
	}

}
