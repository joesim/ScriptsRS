package scripts.api;

/**
 * @author Encoded
 */
public interface Condition07 {

    boolean accept();

}