package scripts;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import org.tribot.api.General;
import org.tribot.api.input.Mouse;
import org.tribot.api2007.Camera;
import org.tribot.api2007.Login;
import org.tribot.api2007.Skills;
import org.tribot.script.Script;
import org.tribot.script.interfaces.Painting;
import org.tribot.script.interfaces.Starting;

import scripts.api.Task;
import scripts.api.TaskSet;
import scripts.spin_logic.BankingHandler;
import scripts.spin_logic.ClickMMBank;
import scripts.spin_logic.ClickMiddleStairs;
import scripts.spin_logic.ClickSpinner;
import scripts.spin_logic.InterfaceHandler;
import scripts.utilities.HoverBox;
import scripts.utilities.MouseMoveJoe;

public class Spinner extends Script implements Starting, Painting {

	public static boolean stop = false;
	public static String action = "";

	@Override
	public void onStart() {
		MouseMoveJoe.loadDataNormal();
		for (Thread thread : Thread.getAllStackTraces().keySet()) {
			if (thread.getName().contains("Antiban") || thread.getName().contains("Fatigue")) {
				thread.suspend();
			}
		}
		Mouse.setSpeed(70);
		HoverBox.load();
	}

	@Override
	public void run() {
		TaskSet tasks = new TaskSet(new ClickMiddleStairs(), new ClickMMBank(), new BankingHandler(),
				new ClickSpinner(), new InterfaceHandler());
		//println(General.getTRiBotUsername());
//		if (!General.getTRiBotUsername().equals("volcom3d")){
//			return;
//		}
		tasks.setStopCondition(() -> stop);

		boolean checked = false;
		while (!tasks.isStopConditionMet()) {
			if (Login.getLoginState().equals(Login.STATE.INGAME) && !checked){
				startXP = Skills.getXP(Skills.SKILLS.CRAFTING);
				checked = true;
			}
			Camera.setCameraAngle(100);
			Camera.setCameraRotation(90);
			Task task = tasks.getValidTask();
			if (task != null) {
				action = task.action();
				task.execute();
			}
			sleep(10, 50);
		}

		Login.logout();
	}


	Font font = new Font("Verdana", Font.BOLD, 14);
	private long startTime = System.currentTimeMillis();
	private long startXP = 0;

	@Override
	public void onPaint(Graphics g) {

		long timeRan = (System.currentTimeMillis() - startTime) / 1000;
		long expGained = Skills.getXP(Skills.SKILLS.CRAFTING) - startXP;
		long bowStringDone = (expGained / 15);
		long bowHour = Math.round(Double.valueOf(bowStringDone) / Double.valueOf(Double.valueOf(timeRan) / 3600));
		g.setFont(font);
		g.setColor(new Color(0, 255, 0));

		g.drawString("Temps: " + String.format("%d:%02d:%02d", timeRan / 3600, (timeRan % 3600) / 60, (timeRan % 60)),
				20, 70);
		g.drawString("Action: " + action, 20, 90);
		g.drawString("Ns: " + bowStringDone, 20, 110);
		g.drawString("S/h: " + bowHour, 20, 130);

		// if (Zulrah.zulrah != null) {
		// g.drawString("Zulrah animation: " + Zulrah.zulrah.getAnimation(),
		// 300, 370);
		// }
		// g.drawString("CheckDeath player : " + CheckDeath.playerDead + " zul:
		// " + CheckDeath.zulrahDead, 200, 390);
		// g.drawString("Player interacting index: " +
		// Player.getRSPlayer().getInteractingIndex(), 200, 410);
		// g.drawString("CheckRed shouldMove " + CheckRed.shouldMove, 200, 430);
		// g.drawString("CheckJad " + CheckJad.shouldSwitch, 200, 450);

	}
}
