package scripts.utilities;

import org.tribot.api.General;
import org.tribot.api2007.Banking;
import org.tribot.api2007.Equipment;
import org.tribot.api2007.Game;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.types.RSItem;

/**
 * Blowpipe helper class
 * 
 * @author volcom3d
 */
public class Blowpipe {

	// * Withdraws a select amount of an item that matches the given name.
	// *
	// *
	// * @param name
	// * Name of the item.
	// * @param amount
	// * Amount of the item to withdraw; 0 to withdraw all.
	// * @return If we withdrew the item or not.
	// */

	public final static String BLOWPIPE = "Toxic blowpipe";
	public final static String ZULRAH_SCALE = "Zulrah's scales";

	/**
	 * Withdraws blowpipe from the bank
	 * 
	 * @return
	 */
	public static boolean withdrawBlowpipe() {
		RSItem[] bp = Banking.find(BLOWPIPE);
		if (bp.length > 0) {
			return Banking.withdrawItem(bp[0], 1);
		}
		return false;
	}

	public static boolean equipBlowpipe() {
		RSItem[] bp = Inventory.find(BLOWPIPE);
		if (bp.length > 0 && !Equipment.isEquipped(BLOWPIPE)) {
			if (Inventory.open()) {
				return bp[0].click("Equip");
			}
		}
		return false;
	}

	public static Integer getDarts() {
		RSItem[] bp = Inventory.find(BLOWPIPE);
		if (bp.length > 0) {
			General.println(bp[0].);
		}
		return 0;
	}

	public static Double getZulrahCharges() {
		return 0.0;
	}

	public static boolean chargeDarts(String dartName) {
		RSItem[] darts = Inventory.find(dartName);
		RSItem[] bp = Inventory.find(BLOWPIPE);
		if (darts.length > 0 && bp.length > 0) {
			if (Inventory.open()) {
				if (!Game.isUptext("Use " +dartName+" ->")){
					return (darts[0].click("Use " + dartName) && bp[0].click("Use "+dartName+" -> "+BLOWPIPE));
				} else{
					return bp[0].click("Use "+dartName+" -> "+BLOWPIPE);
				}
					
			}
		}
		return false;
	}

	public static boolean chargeScales() {
		RSItem[] scales = Inventory.find(ZULRAH_SCALE);
		RSItem[] bp = Inventory.find(BLOWPIPE);
		General.println(scales.length);
		if (scales.length > 0 && bp.length > 0) {
			if (Inventory.open()) {
				if (!Game.isUptext("Use " +ZULRAH_SCALE+" ->")){
					return (scales[0].click("Use " + ZULRAH_SCALE) && bp[0].click("Use "+ZULRAH_SCALE+" -> "+BLOWPIPE));
				} else{
					return bp[0].click("Use "+ZULRAH_SCALE+" -> "+BLOWPIPE);
				}
					
			}
		}
		return false;
	}
	
	public static boolean chargeAll(String dartName) {
		return chargeScales() && chargeDarts(dartName);
	}

}
