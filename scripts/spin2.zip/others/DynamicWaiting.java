package scripts.others;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Mouse;
import org.tribot.api.types.generic.Condition;

import scripts.utilities.AntiBan;

/**
 * Dynamic waiting
 * @author volcom3d
 *
 */
public class DynamicWaiting {

	/** Percentage chance the mouse move each iteration **/
	private static int PERCENT_MOVING = 35;
	
	/** The max distance the mouse will move relative to the rectangle (must be between 0 and 1) **/
	private static Double RECTANGLE_MULTIPLIER = 0.4;
	
	/** Speed mouse during iteration **/
	private static int SPEED_HOVER = General.random(0, 5);
	
	/** Minimum wait **/
	private static int MIN_WAIT = 50;
	
	/** Maximum wait **/
	private static int MAX_WAIT = 2000;

	
	/**
	 * Hovers the mouse in the specified rectangle while the condition is false
	 */
	public static boolean hoverWaitRectangle(Condition c, long timeOut, Rectangle rec) {
		return hoverWait(c, timeOut, null, rec);
	}

	/**
	 * Hovers the mouse in the specified screen rectangle while the condition is false
	 */
	public static boolean hoverWaitScreen(Condition c, long timeOut, Screen screen) {
		return hoverWait(c, timeOut, screen, null);
	}


	/**
	 * Hovers the mouse while the condition is false
	 */
	private static boolean hoverWait(Condition c, long timeOut, Screen screenRec,
			Rectangle rectangle) {
		Integer mSpeed = Mouse.getSpeed();
		Mouse.setSpeed(SPEED_HOVER);
		long t = Timing.currentTimeMillis();
		while (!c.active() && (Timing.currentTimeMillis() - t) < timeOut) {
			if (General.random(0, 100) > PERCENT_MOVING) {
				Timing.waitCondition(c, General.random(MIN_WAIT, MAX_WAIT));
			} else {
				Point pt;
				if (rectangle != null) {
					pt = choosePointRelative(rectangle, RECTANGLE_MULTIPLIER);
				} else {
					pt = choosePointRelative(screenRec.getRectangle(), RECTANGLE_MULTIPLIER);
				}
				Mouse.move(pt);
			}
			AntiBan.timedActions();
		}
		Mouse.setSpeed(mSpeed);
		return c.active();
	}

	/**
	 * Creates a rectangle with the specified parameters
	 */
	public static Rectangle toRectangle(Point middlePoint, Integer width, Integer height) {
		Point upperLeftCorner = new Point(middlePoint.x - width / 2, middlePoint.y - height / 2);
		return new Rectangle(upperLeftCorner, new Dimension(width, height));

	}

	/**
	 * Chooses a point in the relative rectangle
	 */
	private static Point choosePointRelative(Rectangle rec, Double relative) {

		Point goTo;
		if (rec.contains(Mouse.getPos())) {
			Integer xMargin = (int) (Double.valueOf(rec.width) * relative);
			Integer yMargin = (int) (Double.valueOf(rec.height) * relative);
			Point current = Mouse.getPos();
			Integer xMin = (int) ((current.x - xMargin) < rec.getMinX() ? rec.getMinX() : current.x - xMargin);
			Integer xMax = (int) ((current.x + xMargin) > rec.getMaxX() ? rec.getMaxX() : current.x + xMargin);
			Integer yMin = (int) ((current.y - yMargin) < rec.getMinY() ? rec.getMinY() : current.y - yMargin);
			Integer yMax = (int) ((current.y + yMargin) > rec.getMaxY() ? rec.getMaxY() : current.y + yMargin);

			goTo = new Point(General.random(xMin, xMax), General.random(yMin, yMax));
			General.println(goTo);
		} else {
			goTo = new Point((int) General.randomDouble(rec.getMinX(), rec.getMaxX()),
					(int) General.randomDouble(rec.getMinY(), rec.getMaxY()));
		}
		return goTo;
	}
	
	/**
	 * Set min wait when the mouse stands still
	 * @param minWait
	 */
	public static void setMinWait(int minWait) {
		MIN_WAIT = minWait;
	}

	/**
	 * Set max wait when the mouse stands still
	 * @param maxWait
	 */
	public static void setMaxWait(int maxWait) {
		MAX_WAIT = maxWait;
	}

	/**
	 * Set the pchance the mouse will move for each iteration.
	 * @param perMove
	 */
	public static void setPercentMoving(int perMove) {
		PERCENT_MOVING = perMove;
	}

	/**
	 * Set the rectangle multiplier between 0 and 1.
	 * @param recMult
	 */
	public static void setRectangleMultiplier(Double recMult) {
		RECTANGLE_MULTIPLIER = recMult;
	}

	/**
	 * Set the speed of the mouse while hovering
	 * @param speedHover
	 */
	public static void setSpeedHover(int speedHover) {
		SPEED_HOVER = speedHover;
	}

}
