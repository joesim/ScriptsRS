package scripts.webwalker_logic.teleport_logic;


public interface Validatable {
    boolean canUse();
}
