package scripts.utilities;

import java.util.ArrayList;

import org.tribot.api.General;
import org.tribot.api2007.Walking;
import org.tribot.api2007.types.RSTile;

import scripts.webwalker_logic.WebPath;
import scripts.webwalker_logic.WebWalker;

public class WalkingJoe {

	public static void walkingTo(RSTile tile){
		int off = General.random(1, 5);
		WebWalker.Offset offset = null;
		switch (off){
		case 1:
			offset = WebWalker.Offset.LOW;
			break;
		case 2:
			offset = WebWalker.Offset.MEDIUM;
			break;
		case 3:
			offset = WebWalker.Offset.HIGH;
			break;
		case 4:
			offset = WebWalker.Offset.VERY_HIGH;
			break;
		case 5:
			offset = WebWalker.Offset.NONE;
			break;
		}
		General.println("1");
		WebWalker.setPathOffset(offset);
		General.println("2");
		WebWalker.walkTo(tile);
		General.println("3");
	}
	
	public static void walk(RSTile tile, int chance){
		ArrayList<RSTile> path1 = WebPath.getPath(tile);
		for (int i = 0; i<path1.size();i++){
			if (Functions.percentageBool(chance)){
				path1.remove(i); 
			}
		}
		RSTile[] path = path1.toArray(new RSTile[0]);
		Walking.walkPath(path);
	}
	
	public static void walkCharter(){
		
	}
	
}
