package scripts.utilities;

public interface Condition {

	public boolean checkCondition();
	
}
